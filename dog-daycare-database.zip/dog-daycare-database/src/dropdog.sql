{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf600
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0  \
 drop table appt_t;\
 drop table dog_vaccine_t;\
 drop table vaccine_t; \
 drop table service_t;\
 drop table client_dog_t;\
 drop table client_t;\
 drop table dog_t;\
 drop table emerg_t;\
 drop table employee_skill_t;\
 drop table skill_t;\
 drop table employee_t;\
 drop table user_t;}