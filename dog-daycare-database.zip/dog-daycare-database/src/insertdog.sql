{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf600
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 \
-- insert users\
INSERT INTO user_t (user_id,user_name,user_street,user_city,user_state,user_zip,user_phone,user_email,user_pw) VALUES ('00001','Warren Casey','2814 Volutpat Ave','Belmont','MA','02330','0462714005','metuser@aol.com','CWU38WEE0IV');\
INSERT INTO user_t (user_id,user_name,user_street,user_city,user_state,user_zip,user_phone,user_email,user_pw) VALUES ('00002','Abraham Henderson','826 Mauris Rd','Plymouth','MA','01563','4060580383','quam.curabitur@bu.edu','NLY08JBR8RN');\
INSERT INTO user_t (user_id,user_name,user_street,user_city,user_state,user_zip,user_phone,user_email,user_pw) VALUES ('00003','Tiger Fitzgerald','4820 Suspendisse Ave','Birmingham','AL','11805','6372327046','montes.nascetur@gmail.com','YXK36EGJ6QY');\
INSERT INTO user_t (user_id,user_name,user_street,user_city,user_state,user_zip,user_phone,user_email,user_pw) VALUES ('00004','Allistair Orti','7228 Ullamcorper St','Arlington','MA','02486','7318037089','facilisis@gmail.com','UCY35YBC5FN');\
INSERT INTO user_t (user_id,user_name,user_street,user_city,user_state,user_zip,user_phone,user_email,user_pw) VALUES ('00005','Basil Bullock','6870 Idaho Ave','Allston','MA','02134','7459110093','quis.pede@yahoo.net','BKT56WHA3NG');\
INSERT INTO user_t (user_id,user_name,user_street,user_city,user_state,user_zip,user_phone,user_email,user_pw) VALUES ('00006','Laura Kocubinski','1 Banana Ave','Banana Town','MA','12345','0123456789','eu.tellus.eu@ligula.edu','CRW82LYJ7VA');\
INSERT INTO user_t (user_id,user_name,user_street,user_city,user_state,user_zip,user_phone,user_email,user_pw) VALUES ('00007','Talon Austin','9127 Erat Ave','"Patalillo','CA','15789','2104288618','tristique.pharetra@ligula.net','DSB99KAL8AU');\
INSERT INTO user_t (user_id,user_name,user_street,user_city,user_state,user_zip,user_phone,user_email,user_pw) VALUES ('00008','Solomon Mccullough','6106 Et Rd','Norfolk','VA','910902','8791767147','scelerisque@sit.ca','GIK99RLY6PH');\
INSERT INTO user_t (user_id,user_name,user_street,user_city,user_state,user_zip,user_phone,user_email,user_pw) VALUES ('00009','John French','6618 Accumsan St','Castello','MA','57658','8330841102','nunc.ac.mattis@enim.com','YYV80VPH2AA');\
INSERT INTO user_t (user_id,user_name,user_street,user_city,user_state,user_zip,user_phone,user_email,user_pw) VALUES ('00010','Kadeem Miles','816 Quis St','Upplands','MI','07667','2727491646','sagittis.placerat@sed.com','VVR37YPO6QU');\
INSERT INTO user_t (user_id,user_name,user_street,user_city,user_state,user_zip,user_phone,user_email,user_pw) VALUES ('00011','Zeus Leblanc','9283 Iaculis Road','Lagos','LA','05840','0202956951','nisl.elementum@unec.com"','PGD70YFL0NS');\
INSERT INTO user_t (user_id,user_name,user_street,user_city,user_state,user_zip,user_phone,user_email,user_pw) VALUES ('00012','Honorato Russell','9273 Urna St','Kaiserslauter','RI','90915','8594147810','blandit.consequat@rutr.edu','VXR46DFJ1CS');\
\
-- insert emergency contact\
INSERT INTO emerg_t (emerg_id,emerg_name,emerg_street,emerg_city,emerg_state,emerg_zip,emerg_phone,emerg_email) VALUES ('00001','Laura Kocubinski','2 Banana Ave','Banana','MA','12345','0123456789','mauris.blandit@aol.com');\
INSERT INTO emerg_t (emerg_id,emerg_name,emerg_street,emerg_city,emerg_state,emerg_zip,emerg_phone,emerg_email) VALUES ('00002','Seth Moses','457 Adipiscing Ave','Auxerre','WI','82049','4194045624','id@risus.net');\
INSERT INTO emerg_t (emerg_id,emerg_name,emerg_street,emerg_city,emerg_state,emerg_zip,emerg_phone,emerg_email) VALUES ('00003','Caldwell Mills','2962 Neque St','Hoorn','NB','16796','3130017171','sit@vitae.co.uk');\
INSERT INTO emerg_t (emerg_id,emerg_name,emerg_street,emerg_city,emerg_state,emerg_zip,emerg_phone,emerg_email) VALUES ('00004','Maxwell Cotton','810 Enim Ave','Whitby','OR','36908','6652800677','donec.nibh@duiin.net');\
INSERT INTO emerg_t (emerg_id,emerg_name,emerg_street,emerg_city,emerg_state,emerg_zip,emerg_phone,emerg_email) VALUES ('00005','John Marsh','712 Amet Ave','Galway','MI','70326','4653160224','nibh.donec@nulla.edu');\
INSERT INTO emerg_t (emerg_id,emerg_name,emerg_street,emerg_city,emerg_state,emerg_zip,emerg_phone,emerg_email) VALUES ('00006','Clark Schneider','2287 Nulla Street','Mandurah','WA','44232','1268645605','auctor.nunc@etul.com');\
INSERT INTO emerg_t (emerg_id,emerg_name,emerg_street,emerg_city,emerg_state,emerg_zip,emerg_phone,emerg_email) VALUES ('00007','Garrett Hubbard','7276 Est Ave','Vierzon','WY','15789','6311762976','malesuada.ut@saol.com');\
\
-- insert employees\
INSERT INTO employee_t (employee_id,employee_payrate) VALUES ('00001',15.00);\
INSERT INTO employee_t (employee_id,employee_payrate) VALUES ('00002',20.00);\
INSERT INTO employee_t (employee_id,employee_payrate) VALUES ('00003',14.00);\
INSERT INTO employee_t (employee_id,employee_payrate) VALUES ('00004',22.50);\
INSERT INTO employee_t (employee_id,employee_payrate) VALUES ('00005',18.50);\
\
-- insert clients\
INSERT INTO client_t (client_id,emerg_id) VALUES ('00006','00001');\
INSERT INTO client_t (client_id,emerg_id) VALUES ('00007','00002');\
INSERT INTO client_t (client_id,emerg_id) VALUES ('00008','00003');\
INSERT INTO client_t (client_id,emerg_id) VALUES ('00009','00004');\
INSERT INTO client_t (client_id,emerg_id) VALUES ('00010','00005');\
INSERT INTO client_t (client_id,emerg_id) VALUES ('00011','00006');\
INSERT INTO client_t (client_id,emerg_id) VALUES ('00012','00007');\
\
-- insert dogs\
INSERT INTO dog_t (dog_id,dog_name,dog_breed,dog_color,dog_weight,dog_dob) VALUES ('00001','Tink','Poodle','Black',13.0,to_date('01-NOV-17','DD-MON-RR'));\
INSERT INTO dog_t (dog_id,dog_name,dog_breed,dog_color,dog_weight,dog_dob) VALUES ('00002','Fido','Pug','Tan',15.0,to_date('01-JAN-14','DD-MON-RR'));\
INSERT INTO dog_t (dog_id,dog_name,dog_breed,dog_color,dog_weight,dog_dob) VALUES ('00003','Stella','Pitbull','White and Black',45.0,to_date('01-JAN-17','DD-MON-RR'));\
INSERT INTO dog_t (dog_id,dog_name,dog_breed,dog_color,dog_weight,dog_dob) VALUES ('00004','Coco','Chihuahua Mix','Brown',40.0,to_date('01-JAN-16','DD-MON-RR'));\
INSERT INTO dog_t (dog_id,dog_name,dog_breed,dog_color,dog_weight,dog_dob) VALUES ('00005','Brady','Golden Doodle','Tan',25.0,to_date('01-SEP-18','DD-MON-RR'));\
INSERT INTO dog_t (dog_id,dog_name,dog_breed,dog_color,dog_weight,dog_dob) VALUES ('00006','Spot','Beagle','Tan',32.0,to_date('01-JAN-19','DD-MON-RR'));\
INSERT INTO dog_t (dog_id,dog_name,dog_breed,dog_color,dog_weight,dog_dob) VALUES ('00007','Bear','Golden Retriever','Tan',45.0,to_date('01-JUN-15','DD-MON-RR'));\
INSERT INTO dog_t (dog_id,dog_name,dog_breed,dog_color,dog_weight,dog_dob) VALUES ('00008','Pepper','Terrier','Tan',20.0,to_date('01-JAN-12','DD-MON-RR'));\
INSERT INTO dog_t (dog_id,dog_name,dog_breed,dog_color,dog_weight,dog_dob) VALUES ('00009','Oreo','Pomeranian','Black/White',7.0,to_date('01-SEP-13','DD-MON-RR'));\
\
-- insert client dog\
INSERT INTO client_dog_t (client_id,dog_id) VALUES ('00006','00001');\
INSERT INTO client_dog_t (client_id,dog_id) VALUES ('00006','00002');\
INSERT INTO client_dog_t (client_id,dog_id) VALUES ('00007','00003');\
INSERT INTO client_dog_t (client_id,dog_id) VALUES ('00008','00004');\
INSERT INTO client_dog_t (client_id,dog_id) VALUES ('00010','00005');\
INSERT INTO client_dog_t (client_id,dog_id) VALUES ('00011','00006');\
INSERT INTO client_dog_t (client_id,dog_id) VALUES ('00012','00007');\
INSERT INTO client_dog_t (client_id,dog_id) VALUES ('00012','00008');\
INSERT INTO client_dog_t (client_id,dog_id) VALUES ('00012','00009');\
\
-- insert services\
INSERT INTO service_t (service_id,service_description,service_price,service_duration) VALUES ('01','Haircut',50.00,1.0);\
INSERT INTO service_t (service_id,service_description,service_price,service_duration) VALUES ('02','Half-Day',10.00,4.0);\
INSERT INTO service_t (service_id,service_description,service_price,service_duration) VALUES ('03','Full-Day',20.00,8.0);\
INSERT INTO service_t (service_id,service_description,service_price,service_duration) VALUES ('04','Boarding',50.00,24.0);\
INSERT INTO service_t (service_id,service_description,service_price,service_duration) VALUES ('05','Playgroup',20.00,1.0);\
\
-- insert skills\
INSERT INTO skill_t (skill_id,skill_description) VALUES ('01','Grooming');\
INSERT INTO skill_t (skill_id,skill_description) VALUES ('02','Dog Walking');\
INSERT INTO skill_t (skill_id,skill_description) VALUES ('03','Dog Sitting');\
\
-- insert employee skills \
INSERT INTO employee_skill_t (employee_id,skill_id) VALUES ('00001','01');\
INSERT INTO employee_skill_t (employee_id,skill_id) VALUES ('00002','03');\
INSERT INTO employee_skill_t (employee_id,skill_id) VALUES ('00003','03');\
INSERT INTO employee_skill_t (employee_id,skill_id) VALUES ('00004','03');\
INSERT INTO employee_skill_t (employee_id,skill_id) VALUES ('00004','02');\
INSERT INTO employee_skill_t (employee_id,skill_id) VALUES ('00005','01');\
INSERT INTO employee_skill_t (employee_id,skill_id) VALUES ('00005','02');\
\
-- insert appointments\
INSERT INTO appt_t (appt_id,appt_date,appt_time,dog_id,employee_id,service_id) VALUES ('00001',to_date('10-AUG-19','DD-MON-RR'),'2:00 PM','00001','00001','01');\
INSERT INTO appt_t (appt_id,appt_datea,appt_time,dog_id,employee_id,service_id) VALUES ('00002',to_date('15-AUG-19','DD-MON-RR'),'2:00 PM','00002','00004','02');\
INSERT INTO appt_t (appt_id,appt_date,appt_time,dog_id,employee_id,service_id) VALUES ('00003',to_date('8-AUG-19','DD-MON-RR'),'8:00 AM','00001','00003','03');\
INSERT INTO appt_t (appt_id,appt_date,appt_time,dog_id,employee_id,service_id) VALUES ('00004',to_date('8-AUG-19','DD-MON-RR'),'8:00 AM','00005','00004','04');\
INSERT INTO appt_t (appt_id,appt_date,appt_time,dog_id,employee_id,service_id) VALUES ('00005',to_date('8-AUG-19','DD-MON-RR'),'12:00 PM','00003','00003','05');\
\
-- insert vaccines\
INSERT INTO vaccine_t (vaccine_id,vaccine_description) VALUES ('01','Rabies');\
INSERT INTO vaccine_t (vaccine_id,vaccine_description) VALUES ('02','Bordetella (Kennel Cough)');\
INSERT INTO vaccine_t (vaccine_id,vaccine_description) VALUES ('03','Distemper');\
\
-- insert vaccines\
INSERT INTO dog_vaccine_t (dog_id,vaccine_id,vaccine_date) VALUES ('00001','01',to_date('10-MAR-19','DD-MON-RR'));\
INSERT INTO dog_vaccine_t (dog_id,vaccine_id,vaccine_date) VALUES ('00001','02',to_date('10-MAR-19','DD-MON-RR'));\
INSERT INTO dog_vaccine_t (dog_id,vaccine_id,vaccine_date) VALUES ('00004','01',to_date('1-JAN-19','DD-MON-RR'));}